// 配置按钮选择器，可以根据实际页面调整
const BUTTON_SELECTORS = [
    'button:contains("查看表格数据")',
    'button:contains("查看数据")',
    'button:contains("下载表格")',
    '.view-table-data',
    '#viewTableBtn'
];

// 自定义:contains选择器
jQuery.expr[':'].contains = function(a, i, m) {
    return jQuery(a).text().toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
};

// 寻找页面中的目标按钮
function findTargetButtons() {
    let buttons = [];
    
    // 尝试各种选择器
    BUTTON_SELECTORS.forEach(selector => {
        const found = document.querySelectorAll(selector);
        buttons = [...buttons, ...found];
    });
    
    // 去重
    return [...new Set(buttons)];
}

// 提取表格数据
function extractTableData() {
    // 这里假设按钮点击后显示的表格是页面中最新的或特定的表格
    // 可以根据实际情况调整选择器，比如查找最近的表格或特定ID的表格
    
    // 尝试获取所有可见表格
    const tables = document.querySelectorAll('table:visible');
    
    if (tables.length === 0) {
        // 如果没找到可见表格，尝试获取所有表格
        tables = document.querySelectorAll('table');
    }
    
    return Array.from(tables).map((table, index) => {
        // 获取表头
        const headers = Array.from(table.querySelectorAll('th')).map(th => {
            return th.textContent.trim() || `列${index + 1}`;
        });
        
        // 如果没有表头，创建默认表头
        if (headers.length === 0) {
            const firstRowCells = table.querySelectorAll('tr:first-child td');
            headers.push(...Array.from({length: firstRowCells.length}, (_, i) => `列${i + 1}`));
        }
        
        // 获取行数据
        const rows = Array.from(table.querySelectorAll('tbody tr, table tr:not(th)')).map(row => {
            const rowData = {};
            Array.from(row.querySelectorAll('td')).forEach((td, cellIndex) => {
                rowData[headers[cellIndex] || `列${cellIndex + 1}`] = td.textContent.trim();
            });
            return rowData;
        });
        
        return {
            tableName: `表格${index + 1}`,
            data: rows,
            rowCount: rows.length,
            columnCount: headers.length
        };
    });
}

// 为按钮添加点击事件监听
function setupButtonListeners() {
    const buttons = findTargetButtons();
    
    if (buttons.length === 0) {
        // 如果没找到按钮，1秒后重试
        setTimeout(setupButtonListeners, 1000);
        return;
    }
    
    buttons.forEach(button => {
        // 避免重复添加事件
        if (!button.dataset.tableExportListener) {
            button.dataset.tableExportListener = 'true';
            
            button.addEventListener('click', () => {
                // 延迟提取数据，等待表格加载完成
                setTimeout(() => {
                    const tableData = extractTableData();
                    
                    if (tableData.length > 0) {
                        // 发送数据到background.js进行处理
                        chrome.runtime.sendMessage({
                            action: 'downloadTables',
                            data: tableData
                        }, (response) => {
                            if (!response.success) {
                                console.error('下载表格失败:', response.error);
                            }
                        });
                    } else {
                        console.log('未找到表格数据');
                    }
                }, 500); // 可根据实际情况调整延迟时间
            });
            
            // 视觉提示：给目标按钮添加样式
            button.style.backgroundColor = 'rgba(76, 175, 80, 0.1)';
            button.style.border = '1px solid #4CAF50';
        }
    });
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupButtonListeners);
} else {
    setupButtonListeners();
}

// 监听动态内容加载（适用于单页应用）
const observer = new MutationObserver(setupButtonListeners);
observer.observe(document.body, {
    childList: true,
    subtree: true
});
    