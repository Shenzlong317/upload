// 引入SheetJS库
importScripts('xlsx.full.min.js');

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'downloadTables' && request.data) {
        try {
            convertToExcel(request.data);
            sendResponse({ success: true });
        } catch (error) {
            sendResponse({ success: false, error: error.message });
        }
    }
});

// 转换数据为Excel并下载
function convertToExcel(tablesData) {
    // 创建工作簿
    const wb = XLSX.utils.book_new();
    
    // 为每个表格创建一个工作表
    tablesData.forEach((table, index) => {
        // 对于大型数据集，使用更高效的数组方式
        const wsData = [Object.keys(table.data[0] || {})]; // 表头行
        table.data.forEach(row => {
            wsData.push(Object.values(row)); // 数据行
        });
        
        const ws = XLSX.utils.aoa_to_sheet(wsData);
        
        // 设置工作表名称
        let sheetName = table.tableName || `表格${index + 1}`;
        sheetName = sheetName.substring(0, 31);
        
        // 将工作表添加到工作簿
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });
    
    // 生成Excel文件
    const excelData = XLSX.write(wb, { 
        bookType: 'xlsx', 
        type: 'array',
        compression: true // 启用压缩
    });
    
    // 创建Blob对象
    const blob = new Blob([excelData], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
    });
    
    // 创建下载URL
    const url = URL.createObjectURL(blob);
    
    // 生成文件名
    const fileName = `表格数据_${new Date().getTime()}.xlsx`;
    
    // 下载文件
    chrome.downloads.download({
        url: url,
        filename: fileName,
        saveAs: true
    }, () => {
        URL.revokeObjectURL(url);
    });
}
    